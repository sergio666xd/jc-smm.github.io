---
title: Asterisk
layout: icon
categories:
  - Typography
tags:
  - asterisks
  - star
---
